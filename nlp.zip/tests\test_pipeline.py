from nlp.extraction.candidate_extractor import extract_candidate_profile
from nlp.extraction.job_extractor import extract_job_profile
from nlp.parsing.section_detector import detect_sections
from nlp.quality_checks.run_checks import build_candidate_quality_report


def process_candidate(candidate_id, parsed_pages):
    profile = extract_candidate_profile(
        candidate_id,
        parsed_pages
    )

    sections = detect_sections(parsed_pages)

    quality = build_candidate_quality_report(
        parsed_pages,
        sections,
        profile.experience
    )

    return {
        "profile": profile,
        "quality": quality
    }


def process_job(job_id, job_text):
    return extract_job_profile(
        job_id,
        job_text
    )


def test_candidate_pipeline():
    pages = [
        {
            "page": 1,
            "text": "John Doe\n"
                    "john@example.com\n"
                    "Skills\n"
                    "Python, SQL\n"
                    "Experience\n"
                    "Software Engineer - 2022-2024\n"
                    "Education\n"
                    "B.Tech Computer Science\n"
                    "Projects\n"
                    "Resume Screening System\n"
                    "Certifications\n"
                    "AWS Certified"
        }
    ]

    result = process_candidate(
        "TEST_PIPELINE_C001",
        pages
    )

    assert result["profile"].candidate_id == "TEST_PIPELINE_C001"
    assert "python" in result["profile"].skills
    assert "quality" in result
    assert "quality_status" in result["quality"]


def test_job_pipeline():
    job_text = """
    Requirements
    Python
    Machine Learning
    SQL

    Preferred Skills
    React
    Power BI

    Minimum 3 years experience

    Responsibilities
    Develop machine learning applications.
    """

    result = process_job(
        "TEST_PIPELINE_J001",
        job_text
    )

    assert result.job_id == "TEST_PIPELINE_J001"
    assert "python" in result.required_skills
    assert "machine learning" in result.required_skills
    assert "react" in result.preferred_skills
    assert result.minimum_experience == 3.0
