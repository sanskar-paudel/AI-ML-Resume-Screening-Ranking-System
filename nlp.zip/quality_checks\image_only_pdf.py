def check_image_only_pdf(parsed_pages):
    if not parsed_pages:
        return []

    all_text_empty = all(
        not page.get("text", "").strip()
        for page in parsed_pages
    )

    if all_text_empty:
        return [
            "Image-only PDF detected — text extraction may require OCR."
        ]

    return []
