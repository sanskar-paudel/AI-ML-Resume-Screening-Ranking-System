def check_broken_extraction(parsed_pages):
    if not parsed_pages:
        return [
            "No pages extracted — please verify the document."
        ]

    full_text = "\\n".join(
        page.get("text", "")
        for page in parsed_pages
    ).strip()

    if len(full_text) < 50:
        return [
            "Very little text extracted — possible broken extraction."
        ]

    return []
