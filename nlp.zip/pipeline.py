from nlp.extraction.candidate_extractor import extract_candidate_profile
from nlp.extraction.job_extractor import extract_job_profile
from nlp.parsing.section_detector import detect_sections
from nlp.quality_checks.run_checks import build_candidate_quality_report


def process_candidate(candidate_id, parsed_pages):
    profile = extract_candidate_profile(candidate_id, parsed_pages)

    sections = detect_sections(parsed_pages)

    quality = build_candidate_quality_report(
        parsed_pages,
        sections,
        profile.experience
    )

    return {
        "profile": profile,
        "quality": quality
    }


def process_job(job_id, job_text):
    return extract_job_profile(job_id, job_text)
