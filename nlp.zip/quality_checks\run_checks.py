from nlp.quality_checks.missing_sections import check_missing_sections
from nlp.quality_checks.duplicate_sections import check_duplicate_sections
from nlp.quality_checks.unusual_characters import check_unusual_characters
from nlp.quality_checks.timeline_conflicts import check_timeline_conflicts
from nlp.quality_checks.date_format import check_date_format_inconsistency
from nlp.quality_checks.broken_extraction import check_broken_extraction
from nlp.quality_checks.image_only_pdf import check_image_only_pdf


def run_quality_checks(parsed_pages, sections, experience):
    warnings = []

    warnings.extend(check_missing_sections(sections))
    warnings.extend(check_duplicate_sections(sections))

    full_text = "\n".join(
        page.get("text", "")
        for page in parsed_pages
    )

    warnings.extend(check_unusual_characters(full_text))
    warnings.extend(check_timeline_conflicts(experience))
    warnings.extend(check_date_format_inconsistency(experience))
    warnings.extend(check_broken_extraction(parsed_pages))
    warnings.extend(check_image_only_pdf(parsed_pages))

    # Remove duplicate warnings while preserving order.
    warnings = list(dict.fromkeys(warnings))

    return warnings


def build_candidate_quality_report(
    parsed_pages,
    sections,
    experience
):
    warnings = run_quality_checks(
        parsed_pages,
        sections,
        experience
    )

    return {
        "quality_status": "warning" if warnings else "ok",
        "warnings": warnings
    }
