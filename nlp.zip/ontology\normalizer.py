from pathlib import Path
import json
from rapidfuzz import fuzz

ONTOLOGY_PATH = Path(__file__).resolve().parent / "skills.json"

with open(ONTOLOGY_PATH, "r", encoding="utf-8") as f:
    SKILL_ALIASES = json.load(f)


def normalize_skill(skill):
    skill_lower = skill.strip().lower()

    for canonical, aliases in SKILL_ALIASES.items():
        if skill_lower == canonical or skill_lower in aliases:
            return canonical

    return None


def normalize_skills(skills):
    normalized = []

    for skill in skills:
        canonical = normalize_skill(skill)

        if canonical and canonical not in normalized:
            normalized.append(canonical)

    return normalized


def fuzzy_normalize_skill(skill, threshold=90):
    skill_lower = skill.strip().lower()

    exact = normalize_skill(skill_lower)

    if exact:
        return exact

    best_skill = None
    best_score = 0

    for canonical, aliases in SKILL_ALIASES.items():
        for alias in aliases:
            score = fuzz.ratio(skill_lower, alias.lower())

            if score > best_score:
                best_score = score
                best_skill = canonical

    if best_score >= threshold:
        return best_skill

    return None