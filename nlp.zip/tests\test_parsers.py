from nlp.parsing.pdf_parser import parse_pdf
from nlp.parsing.docx_parser import parse_docx
from nlp.parsing.section_detector import detect_sections


def test_section_detector():
    pages = [
        {
            "page": 1,
            "text": "John Doe\nSkills\nPython, SQL\nExperience\nSoftware Engineer"
        }
    ]

    sections = detect_sections(pages)

    assert any(
        item["section"] == "skills"
        for item in sections
    )

    assert any(
        item["section"] == "experience"
        for item in sections
    )


def test_pdf_parser_function_exists():
    assert callable(parse_pdf)


def test_docx_parser_function_exists():
    assert callable(parse_docx)
