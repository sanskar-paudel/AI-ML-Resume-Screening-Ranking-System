from nlp.ontology.normalizer import (
    normalize_skill,
    normalize_skills,
    fuzzy_normalize_skill
)


def test_exact_normalization():
    assert normalize_skill("Python") == "python"
    assert normalize_skill("ML") == "machine learning"
    assert normalize_skill("sklearn") == "scikit-learn"


def test_multiple_normalization():
    skills = [
        "Python3",
        "ML",
        "ReactJS",
        "PowerBI",
        "Python"
    ]

    normalized = normalize_skills(skills)

    assert normalized == [
        "python",
        "machine learning",
        "react",
        "power bi"
    ]


def test_fuzzy_normalization():
    assert fuzzy_normalize_skill("pythn") == "python"
    assert fuzzy_normalize_skill("machin learning") == "machine learning"


def test_unknown_skill():
    assert normalize_skill("randomtechnology") is None
    assert fuzzy_normalize_skill("randomtechnology") is None
