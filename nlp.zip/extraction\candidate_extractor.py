import re
import spacy

from nlp.schemas import CandidateProfile
from nlp.parsing.section_detector import detect_sections
from nlp.ontology.normalizer import SKILL_ALIASES, normalize_skills
from nlp.evidence import create_evidence


# Lightweight spaCy pipeline.
# We use it only for NER; existing regex extraction remains the primary method.
try:
    SPACY_NLP = spacy.load("en_core_web_sm")
except OSError:
    SPACY_NLP = spacy.blank("en")


def extract_contact_details(text):
    email_match = re.search(
        r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}",
        text
    )

    phone_match = re.search(
        r"(?:\+?\d[\d\s().-]{7,}\d)",
        text
    )

    name = None

    # Existing deterministic name extraction.
    for line in text.splitlines():
        line = line.strip()

        if line and "@" not in line and not re.search(r"\d", line):
            name = line
            break

    # spaCy NER as a supporting fallback.
    if name is None and SPACY_NLP.pipe_names:
        doc = SPACY_NLP(text)

        for entity in doc.ents:
            if entity.label_ == "PERSON":
                name = entity.text.strip()
                break

    return {
        "name": name,
        "email": email_match.group(0) if email_match else None,
        "phone": phone_match.group(0) if phone_match else None
    }


def extract_candidate_skills(text):
    text_lower = text.lower()
    found_skills = []

    for canonical, aliases in SKILL_ALIASES.items():
        for alias in aliases:
            pattern = (
                r"(?<![a-z0-9])"
                + re.escape(alias.lower())
                + r"(?![a-z0-9])"
            )

            if re.search(pattern, text_lower):
                found_skills.append(canonical)
                break

    return normalize_skills(found_skills)


def extract_education(sections):
    return [
        item["text"]
        for item in sections
        if item["section"] == "education"
    ]


def extract_experience(sections):
    return [
        {
            "page": item["page"],
            "text": item["text"]
        }
        for item in sections
        if item["section"] == "experience"
    ]


def extract_projects(sections):
    return [
        {
            "page": item["page"],
            "text": item["text"]
        }
        for item in sections
        if item["section"] == "projects"
    ]


def extract_certifications(sections):
    return [
        {
            "page": item["page"],
            "text": item["text"]
        }
        for item in sections
        if item["section"] == "certifications"
    ]


def create_candidate_skill_evidence(sections, skills):
    evidence = []

    for item in sections:
        if item["section"] != "skills":
            continue

        text_lower = item["text"].lower()

        for skill in skills:
            aliases = SKILL_ALIASES.get(skill, [skill])

            for alias in aliases:
                if alias.lower() in text_lower:
                    evidence.append(
                        create_evidence(
                            item["page"],
                            item["text"],
                            skill,
                            "skill",
                            "Skill extracted from Skills section."
                        )
                    )
                    break

    return evidence


def create_candidate_education_evidence(sections, education):
    evidence = []

    for item in sections:
        if item["section"] == "education":
            evidence.append(
                create_evidence(
                    item["page"],
                    item["text"],
                    item["text"],
                    "education",
                    "Education extracted from Education section."
                )
            )

    return evidence


def create_candidate_experience_evidence(sections):
    evidence = []

    for item in sections:
        if item["section"] == "experience":
            evidence.append(
                create_evidence(
                    item["page"],
                    item["text"],
                    item["text"],
                    "experience",
                    "Experience extracted from Experience section."
                )
            )

    return evidence


def create_candidate_project_evidence(sections):
    evidence = []

    for item in sections:
        if item["section"] == "projects":
            evidence.append(
                create_evidence(
                    item["page"],
                    item["text"],
                    item["text"],
                    "project",
                    "Project extracted from Projects section."
                )
            )

    return evidence


def create_candidate_certification_evidence(sections):
    evidence = []

    for item in sections:
        if item["section"] == "certifications":
            evidence.append(
                create_evidence(
                    item["page"],
                    item["text"],
                    item["text"],
                    "certification",
                    "Certification extracted from Certifications section."
                )
            )

    return evidence


def create_candidate_evidence(sections, skills, education):
    evidence = []

    evidence.extend(
        create_candidate_skill_evidence(sections, skills)
    )

    evidence.extend(
        create_candidate_education_evidence(sections, education)
    )

    evidence.extend(
        create_candidate_experience_evidence(sections)
    )

    evidence.extend(
        create_candidate_project_evidence(sections)
    )

    evidence.extend(
        create_candidate_certification_evidence(sections)
    )

    return evidence


def extract_candidate_profile(candidate_id, parsed_pages):
    full_text = "\n".join(
        page.get("text", "")
        for page in parsed_pages
    )

    sections = detect_sections(parsed_pages)

    contact = extract_contact_details(full_text)
    skills = extract_candidate_skills(full_text)
    education = extract_education(sections)
    experience = extract_experience(sections)
    projects = extract_projects(sections)
    certifications = extract_certifications(sections)

    evidence = create_candidate_evidence(
        sections,
        skills,
        education
    )

    return CandidateProfile(
        candidate_id=candidate_id,
        name=contact["name"],
        email=contact["email"],
        phone=contact["phone"],
        education=education,
        experience=experience,
        skills=skills,
        projects=projects,
        certifications=certifications,
        evidence=evidence
    )