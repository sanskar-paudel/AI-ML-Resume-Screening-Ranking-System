import re


def check_date_format_inconsistency(experience):
    formats_found = set()

    for item in experience:
        text = item.get("text", "")

        # Year range: 2020-2021
        if re.search(r"\b20\d{2}\s*-\s*20\d{2}\b", text):
            formats_found.add("year-year")

        # Month + year: Jan 2022, December 2023
        if re.search(
            r"\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+20\d{2}\b",
            text,
            flags=re.IGNORECASE
        ):
            formats_found.add("month-year")

        # Year/year: 2020/2021
        if re.search(r"\b20\d{2}/20\d{2}\b", text):
            formats_found.add("year/year")

        # Year-Present / Year-Current
        if re.search(
            r"\b20\d{2}\s*-\s*(?:Present|Current)\b",
            text,
            flags=re.IGNORECASE
        ):
            formats_found.add("year-present")

    if len(formats_found) > 1:
        return ["Inconsistent date formats detected — please verify."]

    return []
