from nlp.quality_checks.missing_sections import check_missing_sections
from nlp.quality_checks.timeline_conflicts import check_timeline_conflicts
from nlp.quality_checks.date_format import check_date_format_inconsistency
from nlp.quality_checks.unusual_characters import check_unusual_characters
from nlp.quality_checks.broken_extraction import check_broken_extraction
from nlp.quality_checks.image_only_pdf import check_image_only_pdf
from nlp.quality_checks.run_checks import build_candidate_quality_report


def test_missing_sections():
    sections = [
        {"page": 1, "section": "skills", "text": "Python"},
        {"page": 1, "section": "experience", "text": "Developer"}
    ]

    warnings = check_missing_sections(sections)

    assert any("education" in warning for warning in warnings)
    assert any("certifications" in warning for warning in warnings)


def test_timeline_conflict():
    experience = [
        {"page": 1, "text": "Company A 2022-2024"},
        {"page": 2, "text": "Company B 2023-2025"}
    ]

    warnings = check_timeline_conflicts(experience)

    assert len(warnings) > 0


def test_date_format_inconsistency():
    experience = [
        {"page": 1, "text": "Company A Jan 2022 - Dec 2023"},
        {"page": 2, "text": "Company B 2020-2021"}
    ]

    warnings = check_date_format_inconsistency(experience)

    assert len(warnings) > 0


def test_unusual_characters():
    text = "Resume " + "★▒�" * 10

    warnings = check_unusual_characters(text)

    assert len(warnings) > 0


def test_broken_extraction():
    pages = [
        {"page": 1, "text": ""}
    ]

    warnings = check_broken_extraction(pages)

    assert len(warnings) > 0


def test_image_only_pdf():
    pages = [
        {"page": 1, "text": ""},
        {"page": 2, "text": ""}
    ]

    warnings = check_image_only_pdf(pages)

    assert len(warnings) > 0


def test_quality_report():
    pages = [
        {
            "page": 1,
            "text": "Skills\nPython\nExperience\nDeveloper"
        }
    ]

    sections = [
        {"page": 1, "section": "skills", "text": "Python"},
        {"page": 1, "section": "experience", "text": "Developer"}
    ]

    experience = [
        {"page": 1, "text": "Developer 2022-2024"}
    ]

    report = build_candidate_quality_report(
        pages,
        sections,
        experience
    )

    assert "quality_status" in report
    assert "warnings" in report
    assert report["quality_status"] == "warning"
