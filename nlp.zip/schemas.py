from dataclasses import dataclass, field
from typing import List, Dict, Optional


@dataclass
class EvidenceRecord:
    page: Optional[int]
    evidence_text: str
    normalized_item: str
    type: str
    reason: str


@dataclass
class CandidateProfile:
    candidate_id: str
    name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    education: List[str] = field(default_factory=list)
    experience: List[Dict] = field(default_factory=list)
    skills: List[str] = field(default_factory=list)
    projects: List[str] = field(default_factory=list)
    certifications: List[str] = field(default_factory=list)
    evidence: List[EvidenceRecord] = field(default_factory=list)


@dataclass
class JobProfile:
    job_id: str
    required_skills: List[str] = field(default_factory=list)
    preferred_skills: List[str] = field(default_factory=list)
    minimum_experience: Optional[float] = None
    education: List[str] = field(default_factory=list)
    responsibilities: List[str] = field(default_factory=list)
    evidence: List[EvidenceRecord] = field(default_factory=list)
