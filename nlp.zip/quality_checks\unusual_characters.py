def check_unusual_characters(text, threshold=10):
    unusual_count = sum(
        1 for char in text
        if ord(char) > 126
    )

    if unusual_count > threshold:
        return [
            "Unusual characters detected — please verify extraction."
        ]

    return []
