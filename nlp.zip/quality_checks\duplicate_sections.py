COMMON_SECTIONS = {
    "education",
    "experience",
    "skills",
    "projects",
    "certifications"
}


def check_duplicate_sections(sections):
    section_pages = {}

    for item in sections:
        section = item["section"]

        if section in COMMON_SECTIONS:
            section_pages.setdefault(section, set()).add(
                item["page"]
            )

    warnings = []

    for section, pages in section_pages.items():
        if len(pages) > 1:
            warnings.append(
                f"Potential duplicate section detected — please verify: {section}"
            )

    return warnings
