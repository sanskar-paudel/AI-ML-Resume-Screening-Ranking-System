from nlp.extraction.candidate_extractor import (
    extract_candidate_profile,
    extract_candidate_skills
)

from nlp.extraction.job_extractor import extract_job_profile


def test_candidate_skill_extraction():
    text = "Experienced in Python3, ML, sklearn and ReactJS."

    skills = extract_candidate_skills(text)

    assert "python" in skills
    assert "machine learning" in skills
    assert "scikit-learn" in skills
    assert "react" in skills


def test_candidate_profile():
    pages = [
        {
            "page": 1,
            "text": "John Doe\n"
                    "john@example.com\n"
                    "Skills\n"
                    "Python, SQL\n"
                    "Experience\n"
                    "Software Engineer - 2022-2024\n"
                    "Education\n"
                    "B.Tech Computer Science"
        }
    ]

    profile = extract_candidate_profile(
        "TEST_C001",
        pages
    )

    assert profile.candidate_id == "TEST_C001"
    assert profile.email == "john@example.com"
    assert "python" in profile.skills
    assert len(profile.education) > 0
    assert len(profile.experience) > 0


def test_job_profile():
    job_text = """
    Requirements
    Python
    Machine Learning
    SQL

    Preferred Skills
    React
    Power BI

    Minimum 3 years experience

    Responsibilities
    Develop machine learning applications.
    """

    job = extract_job_profile(
        "TEST_J001",
        job_text
    )

    assert job.job_id == "TEST_J001"
    assert "python" in job.required_skills
    assert "machine learning" in job.required_skills
    assert "sql" in job.required_skills
    assert "react" in job.preferred_skills
    assert job.minimum_experience == 3.0
