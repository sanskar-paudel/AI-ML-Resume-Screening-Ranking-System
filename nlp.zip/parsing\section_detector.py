import re


SECTION_PATTERNS = {
    "education": [
        r"^education$",
        r"^academic background$",
        r"^educational background$"
    ],
    "experience": [
        r"^experience$",
        r"^work experience$",
        r"^employment history$",
        r"^professional experience$"
    ],
    "skills": [
        r"^skills$",
        r"^technical skills$",
        r"^key skills$",
        r"^technical expertise$"
    ],
    "projects": [
        r"^projects$",
        r"^academic projects$",
        r"^personal projects$"
    ],
    "certifications": [
        r"^certifications$",
        r"^certificates$",
        r"^professional certifications$"
    ]
}


def detect_section_heading(text):
    cleaned = text.strip().lower()

    for section, patterns in SECTION_PATTERNS.items():
        for pattern in patterns:
            if re.fullmatch(pattern, cleaned):
                return section

    return None


def detect_sections(parsed_pages):
    sections = []
    current_section = "unknown"

    for page_data in parsed_pages:
        page_number = page_data["page"]
        text = page_data.get("text", "")

        for line in text.splitlines():
            line = line.strip()

            if not line:
                continue

            detected_section = detect_section_heading(line)

            if detected_section:
                current_section = detected_section
            else:
                sections.append({
                    "page": page_number,
                    "section": current_section,
                    "text": line
                })

    return sections
