import re


def check_timeline_conflicts(experience):
    periods = []

    for item in experience:
        text = item.get("text", "")

        years = re.findall(r"\b(20\d{2})\b", text)

        if len(years) >= 2:
            start = int(years[0])
            end = int(years[1])

            if end < start:
                start, end = end, start

            periods.append((start, end))

    warnings = []

    for i in range(len(periods)):
        for j in range(i + 1, len(periods)):
            start1, end1 = periods[i]
            start2, end2 = periods[j]

            if start1 <= end2 and start2 <= end1:
                warnings.append(
                    "Potential timeline conflict detected — please verify."
                )
                return warnings

    return warnings
