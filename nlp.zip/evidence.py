from nlp.schemas import EvidenceRecord


def create_evidence(
    page,
    evidence_text,
    normalized_item,
    evidence_type,
    reason
):
    return EvidenceRecord(
        page=page,
        evidence_text=evidence_text,
        normalized_item=normalized_item,
        type=evidence_type,
        reason=reason
    )
