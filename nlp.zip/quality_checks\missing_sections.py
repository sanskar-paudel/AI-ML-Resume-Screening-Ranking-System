COMMON_SECTIONS = {
    "education",
    "experience",
    "skills",
    "projects",
    "certifications"
}


def check_missing_sections(sections):
    detected_sections = {
        item["section"]
        for item in sections
        if item["section"] in COMMON_SECTIONS
    }

    missing = sorted(COMMON_SECTIONS - detected_sections)

    return [
        f"Missing common section — please verify: {section}"
        for section in missing
    ]
