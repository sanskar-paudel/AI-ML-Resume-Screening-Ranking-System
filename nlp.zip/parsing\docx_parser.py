from docx import Document


def parse_docx(docx_path):
    paragraphs = []

    document = Document(docx_path)

    for index, paragraph in enumerate(document.paragraphs):
        text = paragraph.text.strip()

        if text:
            paragraphs.append({
                "index": index,
                "text": text,
                "style": paragraph.style.name
            })

    return paragraphs
