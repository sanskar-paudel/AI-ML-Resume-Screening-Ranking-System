import re

from nlp.schemas import JobProfile
from nlp.ontology.normalizer import SKILL_ALIASES, normalize_skills
from nlp.evidence import create_evidence


JOB_SECTION_PATTERNS = {
    "required": [
        r"^requirements$",
        r"^required skills$",
        r"^required qualifications$",
        r"^must have$"
    ],
    "preferred": [
        r"^preferred skills$",
        r"^preferred qualifications$",
        r"^nice to have$",
        r"^good to have$"
    ]
}


def detect_job_section_heading(text):
    cleaned = text.strip().lower()

    for section, patterns in JOB_SECTION_PATTERNS.items():
        for pattern in patterns:
            if re.fullmatch(pattern, cleaned):
                return section

    return None


def extract_job_skills_by_type(job_text):
    required_skills = []
    preferred_skills = []

    current_section = "required"

    for line in job_text.splitlines():
        line = line.strip()

        if not line:
            continue

        detected_section = detect_job_section_heading(line)

        if detected_section:
            current_section = detected_section
            continue

        line_lower = line.lower()
        found_skills = []

        for canonical, aliases in SKILL_ALIASES.items():
            for alias in aliases:
                pattern = (
                    r"(?<![a-z0-9])"
                    + re.escape(alias.lower())
                    + r"(?![a-z0-9])"
                )

                if re.search(pattern, line_lower):
                    found_skills.append(canonical)
                    break

        if current_section == "preferred":
            preferred_skills.extend(found_skills)
        else:
            required_skills.extend(found_skills)

    return (
        normalize_skills(required_skills),
        normalize_skills(preferred_skills)
    )


def extract_minimum_experience(job_text):
    matches = re.findall(
        r"(?:minimum|min|at least)\s+(\d+(?:\.\d+)?)\s*(?:years?|yrs?)",
        job_text,
        flags=re.IGNORECASE
    )

    if not matches:
        return None

    return min(float(value) for value in matches)


def extract_job_education(job_text):
    education_terms = [
        "b.tech",
        "b.e.",
        "bachelor",
        "b.sc",
        "master",
        "m.tech",
        "m.sc",
        "mba",
        "phd",
        "computer science",
        "information technology"
    ]

    text_lower = job_text.lower()

    return [
        term
        for term in education_terms
        if term in text_lower
    ]


def extract_responsibilities(job_text):
    responsibilities = []

    action_words = (
        "develop",
        "build",
        "design",
        "maintain",
        "analyze",
        "implement",
        "create",
        "manage",
        "deploy"
    )

    for line in job_text.splitlines():
        cleaned = line.strip()

        if not cleaned:
            continue

        if cleaned.lower().startswith(action_words):
            responsibilities.append(cleaned)

    return responsibilities


def create_job_skill_evidence(
    job_text,
    required_skills,
    preferred_skills
):
    evidence = []

    current_section = "required"

    for line in job_text.splitlines():
        line = line.strip()

        if not line:
            continue

        detected_section = detect_job_section_heading(line)

        if detected_section:
            current_section = detected_section
            continue

        line_lower = line.lower()

        skills = (
            preferred_skills
            if current_section == "preferred"
            else required_skills
        )

        for skill in skills:
            aliases = SKILL_ALIASES.get(skill, [skill])

            for alias in aliases:
                if re.search(
                    r"(?<![a-z0-9])"
                    + re.escape(alias.lower())
                    + r"(?![a-z0-9])",
                    line_lower
                ):
                    evidence.append(
                        create_evidence(
                            None,
                            line,
                            skill,
                            "required_skill"
                            if current_section == "required"
                            else "preferred_skill",
                            "Skill extracted from job requirements."
                        )
                    )
                    break

    return evidence


def create_job_evidence(
    job_text,
    required_skills,
    preferred_skills,
    minimum_experience,
    education,
    responsibilities
):
    evidence = []

    evidence.extend(
        create_job_skill_evidence(
            job_text,
            required_skills,
            preferred_skills
        )
    )

    if minimum_experience is not None:
        evidence.append(
            create_evidence(
                None,
                str(minimum_experience) + " years",
                str(minimum_experience),
                "experience_requirement",
                "Minimum experience extracted from job description."
            )
        )

    for item in education:
        evidence.append(
            create_evidence(
                None,
                item,
                item,
                "education_requirement",
                "Education requirement extracted from job description."
            )
        )

    for item in responsibilities:
        evidence.append(
            create_evidence(
                None,
                item,
                item,
                "responsibility",
                "Responsibility extracted from job description."
            )
        )

    return evidence


def extract_job_profile(job_id, job_text):
    required_skills, preferred_skills = extract_job_skills_by_type(
        job_text
    )

    # Remove skills already classified as required from preferred skills.
    preferred_skills = [
        skill for skill in preferred_skills
        if skill not in required_skills
    ]

    minimum_experience = extract_minimum_experience(job_text)
    education = extract_job_education(job_text)
    responsibilities = extract_responsibilities(job_text)

    evidence = create_job_evidence(
        job_text,
        required_skills,
        preferred_skills,
        minimum_experience,
        education,
        responsibilities
    )

    return JobProfile(
        job_id=job_id,
        required_skills=required_skills,
        preferred_skills=preferred_skills,
        minimum_experience=minimum_experience,
        education=education,
        responsibilities=responsibilities,
        evidence=evidence
    )
